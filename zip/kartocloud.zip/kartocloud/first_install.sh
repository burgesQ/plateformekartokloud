#! /bin/bash

if [[ $EUID -ne 0 ]]; then
    echo "This script must be run as root" 1>&2
    echo ""
    read -p "Restart as root ? [y/N]" yn
    case $yn in
	[Yy]* ) sudo ./first_launch.sh;;
	* ) ;;
    esac
    exit 1
fi

curl -sSL https://rvm.io/mpapis.asc | gpg --import -
curl -sSL https://get.rvm.io | bash -s stable --ruby
source /etc/profile.d/rvm.sh
rvm reload
rvm requirements run
rvm install 2.4
rvm use 2.4 --default
sudo gem install bundler
bundle install
