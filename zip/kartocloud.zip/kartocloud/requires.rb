require 'net/http'
require 'json'
require 'open-uri'
require 'nokogiri'
